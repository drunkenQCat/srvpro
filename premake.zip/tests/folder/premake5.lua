premake.out("ok")
