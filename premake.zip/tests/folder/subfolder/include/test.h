// Only used for presence in tests
