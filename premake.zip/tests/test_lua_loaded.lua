foobar(10)
