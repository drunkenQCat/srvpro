return {
	"_preload.lua",
	"gmakelegacy.lua",
	"gmakelegacy_cpp.lua",
	"gmakelegacy_csharp.lua",
	"gmakelegacy_makefile.lua",
	"gmakelegacy_utility.lua",
	"gmakelegacy_workspace.lua",
}
