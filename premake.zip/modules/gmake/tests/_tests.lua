require ("gmake")

return {
	"test_gmake_buildcmds.lua",
	"test_gmake_clang.lua",
	"test_gmake_file_rules.lua",
	"test_gmake_flags.lua",
	"test_gmake_includes.lua",
	"test_gmake_ldflags.lua",
	"test_gmake_linking.lua",
	"test_gmake_makefile.lua",
	"test_gmake_objects.lua",
	"test_gmake_pch.lua",
	"test_gmake_perfile_flags.lua",
	"test_gmake_target_rules.lua",
	"test_gmake_tools.lua",
	"test_gmake_wks.lua"
}
